---
id: 46
layout: birra
nombre:  Cornamusa
tipo:  American Red Ale
ibu:  30
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  5,7 %
alergenos: 
origen: España
pvp: 3.20
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/cornamusa.jpg
categoria: [tostadas_rojas]

---
Cornamusa, palabra náutica elegida para dar nombre a esta cerveza. Es una cerveza fresca, de color cobre con ribetes rojizos, espuma prominente y cremosa. En nariz prevalecen los aromas tropicales como papaya y fruta de la pasión y en boca es fresca y contundente al mismo tiempo, con equilibrio entre el frescor que nos aportan lúpulos como el Citra, Mosaic o Simcoe y las notas de caramelo debido al uso de maltas como la Crystal T50 o la DRC
Medalla de Bronce en Barcelona Beer Challenge 2019



















