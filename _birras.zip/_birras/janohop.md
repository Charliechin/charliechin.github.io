---
id: 30
layout: birra
nombre:  Jano Hop
tipo:  New England IPA
ibu:  32
ebc:
maltas: Extra Pale Ale, Dextrine y Wheat
lupulos: Citra y Mosaic
levaduras: 
formato: Botella 33cl
volumen:  4,2 %
alergenos: 
origen: España
pvp: 3.20
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/janohop.jpg
categoria: [indian_pale_ale]

---
Te obligaron a abandonar este mundo terrenal, dejando tras de ti una estela de nostalgia, una simple ilusión de cómo deberían haber sido las cosas y de cómo fueron en realidad. Pero no te preocupes porque esta cerveza es por y para ti. Batido de lúpulos tropicales y cítricos con la suavidad aterciopelada de la avena. Toda una oda a la cerveza, un poema a la vida. ¡Brindaremos por ti, Jano!

