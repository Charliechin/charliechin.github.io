---
id: 41
layout: birra
nombre:  Engendro
tipo:  American Pale Ale
ibu:  43
ebc:  11
maltas: Extra Pale y CaraMalt
lupulos: Citra, Cascade y Magnum
levaduras: 
formato: Botella 33cl
volumen:  6,2 %
alergenos: 
origen: España
pvp: 3.00
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/engendro.jpg
categoria: [pale_ale]

---
Cerveza macarra y transgresora, irreverente e insolente. ¡Alma rebelde! Toda nuestra pasión cervecera en una botella. Elaborada con 3 lúpulos diferentes, hará de tu nariz un festival de aromas y de tu boca, poesía líquida. Cítrica y resinosa. ¡Te enamorarás!
