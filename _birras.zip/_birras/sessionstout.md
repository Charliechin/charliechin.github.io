---
id: 12
layout: birra
nombre:  Session Stout
tipo:  Stout
ibu:  40
ebc:  110
maltas: Maris Otter Floor Malt, Chocolate, Roasted Barley, Crystal y Avena
lupulos: Cascade
levaduras: ALE
formato: Botella 33cl
volumen:  4,2 %
alergenos: 
origen: España
pvp: 2.80
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/sessionstout.jpg 
categoria: [negra]

---
Una excelente cerveza negra, azabache, que ofrece una oscura espuma duradera. Aromáticamente no es una cerveza intensa, pero sí que aparecen notas de café y algo de torrefacto. Cuando la disfrutes llegará a tu paladar de nuevo el café, además de leve presencia de galleta. Todo perfectamente combinado para disfrutar de una cerveza redonda






