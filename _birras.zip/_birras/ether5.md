---
id: 40
layout: birra
nombre:  Ether 5
tipo:  Double IPA
ibu: 
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Lata 44cl.
volumen:  8,1 %
alergenos: 
origen: Irlanda
pvp: 7.00
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/ether5.jpg
categoria: [indian_pale_ale]

---
Nacida en Irlanda, esta cerveza es muy amarga y de un sabor muy potente. Destaca su consistente aroma botánico y su espesa espuma



























