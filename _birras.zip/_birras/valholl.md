---
id: 5
layout: birra
nombre:  Valhöll
tipo:  Double Dry Hopped New England IPA
ibu: 
ebc:
maltas: Extra Pale, Oat Malt. Dextrine, Wheat y CaraMalt
lupulos: Citra, Mosaic y Cryo Simcoe
levaduras: Windsor y New England (Lallemand)
formato: Lata 33cl.
volumen:  7,2 %
alergenos: Copos de avena y lactosa
origen: España
pvp: 3.80
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/valholl.jpg
categoria: [pale_ale]

---
La vida no es un paseo por un campo tranquilo y sereno. El pasado es aterrador, y el futuro desconcertante. No confíes en la paz: lucha y vive cada momento. Brindemos con esta cerveza elaborada en colaboración con “Valhalla” para celebrar su 1º aniversario.



