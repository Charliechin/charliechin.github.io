---
id: 25
layout: birra
nombre:  Mascarat
tipo:  Black Rye IPA
ibu:  50
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  7,2 %
alergenos: 
origen: España
pvp: 3.90
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/mascarat.jpg
categoria: [indian_pale_ale]

---
Una cerveza que, a pesar de su color es muy bebible y con predominio hacia el lúpulo. En nariz se perciben aromas cítricos, resinosos y pináceos que contrastan con notas a suave chocolate y tostados. De color negro y una buena espuma color canela. El sabor resultante es el equilibrio entre las maltas oscuras y el lúpulo que aporta un marcado amargor. La sensación en boca es cremosa y refrescante a la vez con una carbonatación media. Con esta cerveza hemos querido experimentar y dar un paso más allá con una de las combinaciones más arriesgadas de maltas  y lúpulos cebada, centeno y dry Hopping
Medalla de Plata en el Campeonato Nacional de Cervezas 2018






















