---
id: 43
layout: birra
nombre:  Duvel
tipo:  Belgian Strong Ale
ibu:  33
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  8,5 %
alergenos: 
origen: Bélgica
pvp: 2.50
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/duvel.jpg
categoria: [belga]

---
Una cerveza natural con un amargor sutil, un sabor refinado y un distintivo carácter lúpulo, con una delicada efervescencia y un agradable sabor dulce a alcohol





