---
id: 7
layout: birra
nombre:  Trappistes Rochefort 10
tipo:  Belgian Dark Strong Ale (Quadrupel)
ibu:  27
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  11,3 %
alergenos: 
origen: Bélgica
pvp: 4.00
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/trappistes10.jpg
categoria: [belga]

---
Presenta un color marrón oscuro profundo. Espuma densa y duradera. Su gran fuerza y su cuerpo rotundo se con una complejidad de sabores especiados y terrosos, con notas a castañas y chocolate amargo y reminiscencias a vino de Oporto, cuero, albaricoques y roble - una bebida muy interesante.



