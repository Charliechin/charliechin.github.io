---
id: 42
layout: birra
nombre:  Duvel Tripel Hop Citra
tipo:  Belgian Strong Ale
ibu:  48
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  9,5 %
alergenos: 
origen: Bélgica
pvp: 2.80
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/duveltriple.jpg
categoria: [belga]

---
La clásica Duvel con un nuevo ingrediente: Citra, un lúpulo que destaca por notas cítricas, pomelo, lima y frutas tropicales, que se integran de manera elegante al ya agradable aroma de Duvel. Aromáticamente intensa, para disfrutar sin prisas






