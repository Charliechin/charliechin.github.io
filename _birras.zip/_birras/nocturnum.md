---
id: 20
layout: birra
nombre:  Delirium Nocturnum
tipo:  Belgian Strong Ale
ibu:  26
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  9 %
alergenos: 
origen: Bélgica
pvp: 3.50
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/nocturnum.jpg
categoria: [belga]

---
Calurosa y transparente, con aromas de malta, caramelo y nueces. La Delirium Nocturnum muestra una mezcla de dulzor y especias, normalmente más habitual en las cervezas valonas, donde el chocolate también hace aparición al final, cuando la temperatura más alta del líquido suelta nuevas sensaciones









