---
id: 21
layout: birra
nombre:  Destraperlo Negra
tipo:  Andalusí Robust Porter
ibu:  33,5
ebc:  99,5
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  8 %
alergenos: 
origen: España
pvp: 2.70
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/negra.jpg
categoria: [negra]

---
Cerveza de malta tipo Andalusí Robust Porter, elaborada con seis tipos de malta y cinco variedades de lúpulos. De aspecto marrón oscuro y espuma densa debido a las maltas tostadas y uvas pasas moscatel. Un tipo de cerveza Negra excepcional de entrada suave y retrogusto complejo por la cantidad de notas que persisten. Marida bien con cualquier tipo de dulces








