---
id: 14
layout: birra
nombre:  Santa Rita
tipo:  Lager
ibu: 
ebc:
maltas: Finest Lager
lupulos: Hersbrucket
levaduras: 
formato: Botella 33cl
volumen:  4,4 %
alergenos: 
origen: España
pvp: 1.60
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/santarita.jpg
categoria: [rubia]

---
Nuestra nueva cerveza Premium. Santa Rita es una lager, una cerveza de trago fácil y poco lupulada… Pero Santa Rita no es una lager más, nace con la idea de ser la mejor lager que se ha hecho nunca en nuestro país. Etiqueta diseñada por Doodletown.

