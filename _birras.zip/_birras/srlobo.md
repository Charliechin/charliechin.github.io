---
id: 10
layout: birra
nombre:  Sr. Lobo
tipo:  Sweet Stout
ibu:  40
ebc:
maltas: Pale ale, Caramunich, Carafa, Munich & roasted barley
lupulos: Centennial, Fuggles
levaduras: 
formato: Botella 33cl
volumen:  7 %
alergenos: 
origen: España
pvp: 3.00
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/srlobo.jpg
categoria: [negra]

---
Una cerveza oscura elaborada con chocolate y naranja





