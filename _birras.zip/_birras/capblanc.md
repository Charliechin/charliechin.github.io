---
id: 50
layout: birra
nombre:  Cap Blanc
tipo:  Soft IPA
ibu:  42
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  5 %
alergenos: 
origen: España
pvp: 3.20
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/capblanc.jpg
categoria: [indian_pale_ale]

---
Suave y de baja graduación, color pajizo, brillante, fresca y perfumada, con notas cítricas y florales y un final algo amargo y refrescante
Medalla de Plata en Barcelona Beer Challenge 2018




















