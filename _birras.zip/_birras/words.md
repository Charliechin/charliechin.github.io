---
id: 2
layout: birra
nombre:  Words Are Very Unnecessary
tipo:  Orange Creamsicle Double NEIPA
ibu:  18
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Lata 33cl.
volumen:  8 %
alergenos: 
origen: España
pvp: 3.90
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/words.jpg 
categoria: [pale_ale]
---
Presenta los lúpulos Amarillo, Simcoe & Citra. Hemos utilizado cáscara de naranja en el whirlpool para darle ese extra toque cítrico y tropical y un toque de lactosa para sensación sedosa en boca. La hemos fermentada con levaduras New England para obtener matices de frutas de hueso


























