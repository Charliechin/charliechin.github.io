---
id: 16
layout: birra
nombre:  Destraperlo Rubia
tipo:  Andalusí Pale Ale
ibu:  33,5
ebc:  8,4
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  4,5 %
alergenos: 
origen: España
pvp: 2.50
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/rubia.jpg
categoria: [rubia]

---
Hecha a base de maltas Pilsen y lúpulos americanos, de estilo pale ale, esta cerveza está elaborada con una gran proporción de maltas pálidas y agua blanda, al estilo de la ale pálida (pale ale), la cual, tiene un amargor suave y equilibrado. De aspecto paja dorada con espuma pequeña y persistente. Sabor suave y cremosa con un sutil amargor de lúpulos y especias. Los sabores de la levadura influyen en su carácter ácido y lupulado de final fresco y seco. Los aromas están marcados por las variedades de lúpulos usados que le otorgan un aroma especiado y floral






