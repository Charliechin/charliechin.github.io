---
id: 3
layout: birra
nombre:  Vedett Extra White
tipo:  Witbier
ibu:  4
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  4,7 %
alergenos: 
origen: Bélgica
pvp: 2.30
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/vedettwhite.jpg
categoria: [trigo]

---
Esta cerveza es increíblemente refrescante, perfecta para calmarla sed, con un final meloso y dulce, ligeramente perfumado, con notas de ralladura de naranja y limón, redondeado con un sabor ligeramente amargo y final seco

