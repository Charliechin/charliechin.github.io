---
id: 57
layout: birra
nombre:  Althaia IPA
tipo:  Indian Pale Ale
ibu:  57,7
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  6,5 %
alergenos: 
origen: España
pvp: 3.20
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/althaiaipa.jpg
categoria: [indian_pale_ale]

---
Rindiendo homenaje a uno de los estilos más populares hemos creado nuestra IPA Althaia Artesana, con la utilización exclusiva de lúpulos americanos, para ensalzar el carácter fresco, tropical y resinoso y con el uso del Dry Hopping para darnos un intenso y fresco aroma a lúpulo. Obtenemos así esta cerveza de brillante color ambarino y una espuma compacta, aromas florales, frescos y una entrada en boca contundente
Medalla de Oro en Madrid Brew Competition 2019
 Medalla de Plata en Barcelona Beer Challenge 2019
 Medalla de Plata en el Campeonato Nacional de Cervezas 2018
 Medalla de Bronce Barcelona Beer Challenge 2016


















