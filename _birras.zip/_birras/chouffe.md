---
id: 48
layout: birra
nombre:  Mc Chouffe
tipo:  Belgian Strong Ale (Scotch Ale)
ibu: 
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  8 %
alergenos: 
origen: Bélgica
pvp: 2.60
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/chouffe.jpg
categoria: [belga]

---
Esta ale es oscura, de color cobre a rubí, alcohólica, con notas especiadas y frutales, tiene un amargor a lúpulo bastante balanceado, con sabores a cuero y frutas negras. Por su sabor afrutado y servida bien fresca es una cerveza para degustar y para consumo moderado entre amigos y que acompaña bien a carne de caza estofada







