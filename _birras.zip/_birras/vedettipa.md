---
id: 4
layout: birra
nombre:  Vedett Extra Ordinary IPA
tipo:  Indian Pale Ale
ibu:  40
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  5,5 %
alergenos: 
origen: Bélgica
pvp: 2.30
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/vedettipa.jpg 
categoria: [pale_ale]
---
Ofrece una explosión de amargura sabrosa que aumenta con intensidad, atenuada por una suavidad aterciopelada sin igual con un resultado de sabor muy accesible. Las notas frescas, afrutadas y florales junto a los toques de dulzura de caramelo, da como resultado su excelente y persistente sabor. Dando lugar a una cerveza muy refrescante











