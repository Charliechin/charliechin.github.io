---
id: 27
layout: birra
nombre:  Malaspina Weissbier
tipo:  Weissbier
ibu: 
ebc:
Maltas:
Lúpulos:
levaduras: 
formato: Botella 33cl
volumen:  5,5 %
alergenos: 
origen: España
pvp: 3.00
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/malaspina.jpg
categoria: [trigo]

---
Cerveza de estilo Weissbier elaborada a partir de una selección de maltas de cebada y trigo, dando como resultado una cerveza ligera y refrescante de color ámbar oscuro con un sabor suave y un intenso aroma a trigo, presentando espuma consistente y una carbonización considerable




