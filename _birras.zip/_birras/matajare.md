---
id: 24
layout: birra
nombre:  Matajare
tipo:  American Pale Ale
ibu:  32
ebc:  7,4
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  5 %
alergenos: 
origen: España
pvp: 2.80
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/matajare.jpg
categoria: [pale_ale]

---
Elaborada con 2 maltas de cebada (Pilsen y Munich) y 6 lúpulos (Summit, Cascade, Willamete, Haller tower, Sincoe, Mosaic). Segunda fermentación en botella con azúcar de caña. Apariencia: de color dorado turbio y carbonatación moderada con espuma blanca y burbujas compactas. Aroma: complejo que combina bien sus 6 lúpulos, floral, tropical, con recuerdos a mango, maracuyá, ligeramente cítrico y con un toque a cereal. Sabor: refrescante y ligera, con un toque de amargor en el retrogusto. Sabor persistente a lúpulo y con un soniquete envolvente.  Servir entre 6º y 9º.










