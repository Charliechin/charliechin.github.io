---
id: 11
layout: birra
nombre:  Sidama
tipo:  Brown Coffee Porter
ibu:  24
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  5,8 %
alergenos: 
origen: España
pvp: 3.20
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/sidama.jpg
categoria: [negra]

---
Cerveza de color caoba, con base de café y de espuma cremosa y consistente de color vainilla. Los aromas característicos de este café recién tostado y molido se han conseguido integrar en esta cerveza mediando una infusión previa en frio llamada – cold brew – añadiendo esta durante su elaboración. El café nos aporta notas de frutos rojos, moka y toffee. En boca tenemos una refrescante acidez gracias al juego de maltas y la aportación del café, con retrogusto a frutillas rojas como la grosella. Esta es sin duda una cerveza refrescante y de trago largo, con una burbuja fina y muy bien integrada debido a la fermentación natural





















