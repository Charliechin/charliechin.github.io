---
id: 18
layout: birra
nombre:  Rabosa
tipo:  Pumpkin Ale
ibu: 
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  6,2 %
alergenos: 
origen: España
pvp: 3.20
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/rabosa.jpg
categoria: [tostadas_rojas]

---
Es una cerveza naranja-cobre, especiada, con un cuerpo pleno que sugiere un buen acompañamiento para los vientos frescos del otoño, evocando las tradicionales calabazas asadas que encontramos en los hornos y mercados de nuestra zona. Su aroma es una reminiscencia a pastel de calabaza, complejo, armonioso y especiado. Su espuma está bien formada con una dulce maltosidad en boca que recuerda al pastel de calabaza o las galletas de jengibre





















