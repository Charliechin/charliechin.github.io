---
id: 54
layout: birra
nombre:  Barcelona
tipo: Pale Ale
ibu:  20
ebc:
maltas: Pale Ale, Caramunich T2, F. Oat
lupulos: Magnum, Perle, Cascade
levaduras: 
formato: Botella 33cl
volumen:  5 %
alergenos: 
origen: España
pvp: 2.30
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/barcelona.jpg
categoria: [pale_ale]

---
Barcelona es inspiración, es creatividad y es Mediterráneo. Es amable y acogedora. Nuestra cerveza también. Elaborada con un agua increíblemente pura y una selección de maltas y lúpulos para conseguir una cerveza muy especial. Si te gusta Barcelona, te gustará nuestra cerveza. Diseño de Àlex Trochut
Etiqueta premiada con un LAUS y en los NEW YORK DESIGNAWARDS




