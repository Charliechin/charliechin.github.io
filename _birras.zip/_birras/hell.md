---
id: 35
layout: birra
nombre:  Hell
tipo:  Bavarian helles
ibu:  20
ebc:
maltas: Pilsen, Carahell
lupulos: Hallertauer y Mosaic
levaduras: 
formato: Botella 33cl
volumen:  5,5 %
alergenos: 
origen: España
pvp: 2.70
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/hell.jpg
categoria: [rubia]

---
Sabor suave y pleno, bien definida, gusto redondeado y ligeramente afrutado, de burbuja fina, espuma cremosa y consistente. Delicadamente balanceada










