---
id: 51
layout: birra
nombre:  Blackbell
tipo:  Baltic Coffee Porter
ibu:  30
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  8,7 %
alergenos: 
origen: España
pvp: 3.30
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/blackbell.jpg
categoria: [negra]

---
Esta cerveza artesana negra estaría dentro de la categoría de una Baltic Porter, cervezas con una alta graduación. Nos encontramos con una cerveza oscura, de espuma beige ligera que desaparece rápidamente. Aromas a malta tostada y café













