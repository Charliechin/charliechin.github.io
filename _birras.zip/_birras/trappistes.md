---
id: 8
layout: birra
nombre:  Trappistes Rochefort 8
tipo:  Belgian Dark Strong Ale
ibu:  22
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  9,2 %
alergenos: 
origen: Bélgica
pvp: 3.20
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/trappistes.jpg
categoria: [belga]

---
Auténtica cerveza trapense. Es una cerveza con un sabor fuerte y complejo, así como con un cuerpo firme. El aroma tiene notas de fruta fresca, especias, cuero e higos Color marrón oscuro, que produce una capa de espuma buena y persistente con un color beige cremoso. El aroma es dulzón y afrutado con un punto de alcohol, y esas mismas notas vuelven a aparecer en la boca, frutas pasas, malta con una textura cremosa


