---
id: 9
layout: birra
nombre:  The Fits
tipo:  Imperial IPA
ibu:  70
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Lata 33cl.
volumen:  9 %
alergenos: 
origen: España
pvp: 3.60
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/thefits.jpg
categoria: [indian_pale_ale]

---
Intensa y bastante frutal. Se presenta de un color ambarino con cierta turbidez y una cremosa espuma blanca. Las notas a pomelo, piña y otras frutas tropicales dominan en nariz en boca, con un amargor moderado y recuerdos a resina al final del trago
























