---
id: 49
layout: birra
nombre:  Cerdos Voladores
tipo:  Indian Pale Ale
ibu:  65
ebc:
maltas: Pale Ale, Carahell, Crystal
lupulos: Centennial, Amarillo & Cascade
levaduras: 
formato: Botella 33cl
volumen:  6 %
alergenos: 
origen: España
pvp: 2.60
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/cerdosvoladores.jpg
categoria: [indian_pale_ale]

---
Los 3 Cerditos han vuelto... convertidos en cerveza. Los Cerdos Voladores es nuestra cerveza más gamberra y simpática. Una cerveza potente y descarada para los momentos más alegres. Con mucho lúpulo que le da un punto amargo. ¡Te enganchará! Be Cerdo my friend!



