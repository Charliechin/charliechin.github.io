---
id: 33
layout: birra
nombre:  Destraperlo IPA
tipo:  Andalusí Inda Pale Ale
ibu: 
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  5,5 %
alergenos: 
origen: España
pvp: 2.80
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/ipa.jpg
categoria: [indian_pale_ale]

---
Variedad de cerveza inglesa que se caracteriza como una ale pálida y espumosa con un alto nivel del alcohol y de lúpulo. La creación de la Indian Pale Ale durante la década de 1790 fue el resultado de esfuerzos de los cerveceros británicos por superar un problema difícil: a comienzos del siglo XVIII la cerveza no se conservaba bien en los largos viajes por el océano, especialmente en climas cálidos. Estos ambientes hacían que la cerveza se volviese caduca y agria









