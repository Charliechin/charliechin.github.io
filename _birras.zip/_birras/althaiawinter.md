---
id: 56
layout: birra
nombre:  Althaia Winter Ale
tipo:  Winter Ale
ibu:  20
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  8 %
alergenos: 
origen: España
pvp: 3.20
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/althaiawinter.jpg
categoria: [indian_pale_ale]

---
Edición estacional para disfrutar de los días más fríos del año. En nariz se perciben los aromas de dulces especiados y fruta escarchada que combinan a la perfección con una boca untuosa y gusto a grano de café, moka y pralinés. Estas características hacen de esta cerveza un maridaje perfecto de aperitivos ahumados e ibéricos, o incluso como sobremesa con dulces, turrones y mantecados
Medalla de Plata en Barcelona Beer Challenge 2017
Medalla de Bronce en Barcelona Beer Challenge 2016





















