---
id: 36
layout: birra
nombre:  Happy Hoppy
tipo:  Indian Pale Ale
ibu:  58
ebc:  19
maltas: Pale Ale y Caramünich tipo I
lupulos: Chinook, Columbus y Magnum
levaduras: 
formato: Botella 33cl
volumen:  5,9 %
alergenos: 
origen: España
pvp: 3.00
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/happyhoppy.jpg
categoria: [indian_pale_ale]
---
Cerveza amarga y sorprendente, no te dejará indiferente. Para tomar tranquilamente, sin prisas. Elaborada con ingentes cantidades de lúpulo, no es apta para blandengues. Muy equilibrada gracias a la malta caramelo. De carácter resinoso. ¡Es adictiva!
