---
id: 39
layout: birra
nombre:  Flower Sour Hibiscus
tipo:  New England IPA
ibu: 
ebc:
maltas: Extra Pale, Dextrine, Wheat Malt y Oat Malt
lupulos: Citra, Mosaic, Enigma y Ekuanot
levaduras: Windsor y New England (Lallemand)
formato: Lata 33cl.
volumen:  5,5 %
alergenos: 
origen: España
pvp: 3.80
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/flower.jpg
categoria: [indian_pale_ale]

---
New England IPA ligeramente ácida y amarga, elaborada con una infusión de flor de hibisco en caliente, y otra adición en frío. Cerveza de color rojo intenso y muy turbia. Aroma a lúpulos cítricos, tal cual se  espera de una NEIPA, pero con el sabor de una Sour. 20 gramos por litro de lúpulos Citra, Mosaic,  Enigma y Ekuanot, más 10 gramos de flor de hibisco desecada. Esta es la primera cerveza ácida que  producimos a gran escala. Compleja y diferente, un desafío para tus sentidos. ¿Te atreves?


