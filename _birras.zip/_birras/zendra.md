---
id: 1
layout: birra
nombre:  Zendra
tipo:  Rye Bock Rauchbier
ibu:  30
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  7,8 %
alergenos: 
origen: España
pvp: 3.30
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/zendra.jpg
categoria: [tostadas_rojas]

---
Cerveza de edición limitada, pensada para el consumo nocturno. Sólo 3.000 litros por temporada a base de centeno, humo y un poco de Valencia en cada botella. Esta receta se entronca con los populares estilos ahumados origen alemán (Rauchbier). Cervezas, como la Zendra, con gran presencia de las maltas  y un agradable aroma y sabor a madera quemada que refuerzan su personalidad











