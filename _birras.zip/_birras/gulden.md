---
id: 37
layout: birra
nombre:  Gulden Draak
tipo:  Strong Ale
ibu:  30
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  10,5 %
alergenos: 
origen: Bélgica
pvp: 2.90
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/gulden.jpg
categoria: [belga]

---
Oscura y de cremosa espuma, presenta una gama de aromas en que domina el de tueste de la malta Sabor equilibrado, profundo y amplio, donde el dulzor del mosto se mezcla con el amargor de los lúpulos.  Su alto contenido en alcohol y su botella blanca nos aseguran una maduración en bodega durante años




