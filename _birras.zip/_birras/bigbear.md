---
id: 52
layout: birra
nombre:  Big Bear
tipo:  Pale Ale
ibu:  25
ebc:
maltas: Pale Ale, Caramunich T2, Carafa, F. Oat
lupulos: Northern Brewer, Fuggles, Keant East Golding
levaduras: 
formato: Botella 33cl
volumen:  5 %
alergenos: sin gluten
origen: España
pvp: 2.50
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/bigbear.jpg
categoria: [pale_ale]

---
Frank, el oso tranquilo, está muy cabreado. No soporta que se beba mala cerveza. Ahora ha salido de su cueva para luchar contra la cerveza de baja calidad. Big Bear es una cerveza clásica de estilo Pale Ale. Muy al estilo inglés... una cerveza como las de antes, elaborada según método tradicional. Diseñado por Brosmind, dos genios del diseño reconocidos en todo el mundo





