---
id: 34
layout: birra
nombre:  I Am Easy Easy
tipo:  India Pale Lager
ibu:  27
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Lata 33cl.
volumen:  6,8 %
alergenos: 
origen: España
pvp: 3.60
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/iameasyeasy.jpg
categoria: [rubia]

---
Una cerveza robusta con extra cuerpo aportado por la malta de avena y la malta Crystal. Hemos utilizado lúpulo Amarillo y Simcoe en el dryhopping por su vibrante aroma y sabor de naranja, papaya y de pino

























