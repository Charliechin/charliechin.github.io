---
id: 17
layout: birra
nombre:  Raver
tipo:  Indian Pale Ale
ibu: 
ebc:
maltas: Pilsner, Caragold, Munich y Acidulated
lupulos: Citra, Mosaic y Magnum
levaduras: BRY-97
formato: Lata 44cl.
volumen:  7,2 %
alergenos: 
origen: UK
pvp: 9.00
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/raver.jpg
categoria: [indian_pale_ale]

---
Gran cerveza para disfrutar con una buena compañía. Grandes notas de lúpulo y largo recorrido en boca. Una cerveza muy especial
