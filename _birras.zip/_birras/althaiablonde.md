--- 
id: 59
layout: birra
nombre:  Althaia Blonde Ale
tipo:  Blonde Ale
ibu:  23.5
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  5,5 %
alergenos: 
origen: España
pvp: 2.60
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/althaiablonde.jpg
categoria: [rubia]

---
Cerveza mediterránea de alta fermentación. De color pajizo dorado. En nariz prevalecen los aromas de cereal y cítricos. En boca es una cerveza de trago largo con buen cuerpo, forma un rosario fino de burbuja bien integrada. Esta cerveza representa muy buen equilibrio entre el dulzor y los sabores de cereal debido a la doble malta y el frescor del lúpulo que le confieren los aromas cítricos sin abusar de los amargos
Medalla de Bronce en Barcelona Beer Challenge 2016
















