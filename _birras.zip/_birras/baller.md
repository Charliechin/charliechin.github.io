---
id: 55
layout: birra
nombre:  Baller
tipo:  Indian Pale Ale
ibu: 
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Lata 33cl.
volumen:  5,4 %
alergenos: 
origen: UK
pvp: 4.60
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/baller.jpg
categoria: [indian_pale_ale]

---
Muy buenas, os presento a Baller. Baller es IPA 100%, desarrollado desde la experiencia y los años del legado cervecero londinense. Baller es la go to IPA para el día a día, ligera, fresca y con una baja graduación. Cuerpo suave y agradable






























