---
id: 32
layout: birra
nombre:  IPA 4
tipo:  Indian Pale Ale
ibu:  60
ebc:  15
maltas: Extra Pale
lupulos: Mosaic y Centennial
levaduras: ALE
formato: Botella 33cl
volumen:  6 %
alergenos: 
origen: España
pvp: 3.00
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/ipa4.jpg
categoria: [pale_ale]

---
Una de las cervezas estrella de la marca, elaborada con lúpulos Mosaic y Centenial. Intenso aroma floral y a cítricos. Color muy claro. Baja carbonatación. De intenso sabor a cítricos, pomelo y limón, con un final amargo








