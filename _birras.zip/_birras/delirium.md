---
id: 45
layout: birra
nombre:  Delirium Tremens
tipo:  Pale Ale
ibu:  26
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  8,5 %
alergenos: 
origen: Bélgica
pvp: 3.30
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/delirium.jpg
categoria: [belga]

---
Rubia pálida, con una efervescencia excelente y regular que garantiza una espuma espléndida y estable. Aroma: ligera nota de malta, con un agradable toque de alcohol, picante. Sabor: Parece como si el sólido trago de alcohol encendiera la boca. En realidad, calienta la lengua y el paladar. El sabor se caracteriza por su redondez. El regusto es fuerte, duradero y con un amargor seco. Te hará viajar por el cosmos si te excedes en su consumo








