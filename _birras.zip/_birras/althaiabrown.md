---
id: 58
layout: birra
nombre:  Althaia Brown Ale
tipo:  Brown Ale
ibu:  21
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  5,3 %
alergenos: 
origen: España
pvp: 2.60
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/althaiabrown.jpg
categoria: [tostadas_rojas]

---
Cerveza tostada de alta fermentación. De color ambarino, brillante y cristalina. Bien servida nos ofrece una espuma marcada tipo moka y una burbuja fina y bien integrada. En nariz destacan los aromas de caramelo, almendras tostadas o cacao amargo. En boca es una cerveza de elegante frescor en la que prevalecen los sabores del malteado al amargor del lúpulo, que queda en un segundo plano para deleitarnos así con los aromas de frutos secos y chocolate
Plata Brown British Beer en Barcelona Beer Challenge 2016.
 Oro English Brown Ale en Barcelona Beer Challenge 2017

















