---
id: 31
layout: birra
nombre:  IPA 9
tipo:  Double Dry Hopped IPA
ibu:  49
ebc:  13
maltas: Marist Otter, Trigo malteado y Caragold
lupulos: Simcoe y Cascade
levaduras: 
formato: Botella 33cl
volumen:  5,5 %
alergenos: sin gluten
origen: España
pvp: 3.20
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/ipa9.jpg
categoria: [indian_pale_ale]

---
Cerveza de color rubio, algo turbia, espuma blanca, jabonosa y persistente. Aromas frutales y cítricos, y un gusto cítrico (a pomelo) y muy lupulado. Cuerpo medio, sedosa (se nota la avena en su elaboración) y gusto a lúpulo muy persistente. Final amargo y resinoso







