---
id: 23
layout: birra
nombre:  Metro
tipo:  New England Pale Ale
ibu: 
ebc:
maltas: Lager, IPA, Wheat, Oat, Carapils, Acidulated, Flaked Oats
lupulos: El Dorado, Azacca, Kohatu y Magnum
levaduras: 
formato: Lata 44cl.
volumen:  5,5 %
alergenos: 
origen: UK
pvp: 7.00
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/metro.jpg
categoria: [pale_ale]

---
Fuertemente lupulada para tomar a altas horas de la noche o en esas calurosas mañanas





























