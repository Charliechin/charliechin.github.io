---
id: 6
layout: birra
nombre:  Destraperlo Trigo
tipo:  Andalusí-Ecológica-Weissbier
ibu:  6,9
ebc:  8,3
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  3,5 %
alergenos: 
origen: España
pvp: 2.70
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/trigo.jpg
categoria: [trigo]

---
Cerveza de malta tipo "Andalusí Ecológica Weissbier" o cerveza blanca, tal y cómo se designa a las de trigo. Elaborada con dos tipos de malta de cebada, malta de trigo y una variedad de lúpulo. De aspecto pajizo con carbonatación suave. Cerveza refrescante y amable, aparentemente sencilla hasta que afloran matices aportados por la cáscara de naranja amarga y el cilantro. Las tonalidades a plátano son el carácter más presente aportada por el tipo de levadura. Todo ello elaborado con ingredientes 100% ecológicos cumpliendo estrictamente la normativa europea de producción ecológica








