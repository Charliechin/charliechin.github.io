---
id: 47
layout: birra
nombre:  Destraperlo Colorá
tipo:  Andalusí Red Ale
ibu:  22,1
ebc:  35,3
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  6,5 %
alergenos: 
origen: España
pvp: 2.60
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/colora.jpg
categoria: [tostadas_rojas]

---
Cerveza que no dejará indiferente a nadie. Aunque se puede incluir dentro de las Brown Ale, es tan distinta que hemos creado estilo, el Andalusí Robust Porter. Elaborada con seis tipos de maltas y tres variedades de lúpulo tiene un marcado sabor especiado. De aspecto rojizo gracias a las maltas tostadas usadas, pero también al uso de remolacha en su receta, produce una espuma blanquecina fina y resistente. Posee un especiado sabor a romero, contrapesado con un bajo amargor. Muy aromática debido a la mágica conjunción de ingredientes que componen esta compleja cerveza







