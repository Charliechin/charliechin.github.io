---
id: 53
layout: birra
nombre:  Barlovento
tipo:  Imperial Stout
ibu:  44
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  10,4 %
alergenos: 
origen: España
pvp: 3.90
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/barlovento.jpg
categoria: [negra]

---
Intensa y robusta gracias a las notas ahumadas y el toque especial del haba tonka que le confieren ese carácter único. Pensada para auténticos marineros, hecha para degustar en una buena copa y apreciar así su espesa espuma color canela y sentir como llegan a los sentidos su complejo sabor, rico y profundo






















