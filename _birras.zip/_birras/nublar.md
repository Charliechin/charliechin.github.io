---
id: 19
layout: birra
nombre:  Nublar
tipo:  American Amber Ale
ibu:  35
ebc:
maltas: 
lupulos: 
levaduras: 
formato: Botella 33cl
volumen:  6,2 %
alergenos: 
origen: España
pvp: 3.10
imagen: https://labodegadellupulo.s3.eu-west-3.amazonaws.com/images/birras/nublar.jpg
categoria: [tostadas_rojas]

---
Una clásica Amber Ale americana, con un dry hopping de lúpulo Chinook, que le ofrece los aromas a pino y resina. También aparece el aroma a caramelo y torrefacto de las maltas  que, después, se prolonga en boca, donde aparecen notas de frutos rojos. Una cerveza seca, con cuerpo, balance y una espuma de color ocre, fina y abundante. Para los amantes de las tostadas: invita a beber y beber












